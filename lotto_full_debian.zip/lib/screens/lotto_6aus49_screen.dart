import 'package:flutter/material.dart';
import 'lotto6/lotto6_screen.dart';

/// Wrapper, damit der alte Name `Lotto6aus49Screen` weiterverwendet werden kann.
class Lotto6aus49Screen extends StatelessWidget {
  const Lotto6aus49Screen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Lotto6Screen();
  }
}
